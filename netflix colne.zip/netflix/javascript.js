const tabitems = document.querySelectorAll('.tab-item');
const tabcontentitems = document.querySelectorAll('.tab-content-item');

//select tab content item
function selectItem(e) {
    removeBorder();
    removeshow();

    //add border to current tab
    this.classList.add('tab-border');
    //grap content item from dom
    const tabcontentitems = document.querySelector('#$(this.id)-content');
    tabcontentitems.classList.add('show');
}
function removeBorder() {
    tabitems.forEach(item => item.classList.remove('tab-border'))
}
function removeshow() {
    tabcontentitems.forEach(item => item.classList.remove('show'))
}

// listen for tab click
tabitems.forEach(item => item.addEventListener('click', selectItem));